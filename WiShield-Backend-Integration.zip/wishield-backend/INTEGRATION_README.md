# WiShield — backend integration

This wires a real Wi-Fi scanning and rogue-AP detection backend into your existing WiShield frontend. Your visual design is unchanged: same colours, fonts, card shapes, spacing and layout structure.

## What was missing before

- `MainActivity` faked the scan with `new Handler().postDelayed(..., 3000)` and went straight to the dashboard.
- `DashboardActivity` only called `setContentView` — no logic at all.
- `activity_dashboard.xml` had two hardcoded cards ("gmi" and "[rogue ap]") and three stat counters permanently reading `0`.
- `AndroidManifest.xml` declared **no permissions**, so a real scan wasn't possible.

## Files to copy

### New files (just add them)

```
app/src/main/java/com/example/wishieldrogueaccesspointdetectorapp/
  model/AccessPoint.java          one scanned network + its verdict and reasons
  model/Verdict.java              SAFE / SUSPICIOUS / ROGUE
  detect/RogueDetector.java       ← the core detection logic
  detect/OuiLookup.java           MAC → vendor, and software-MAC detection
  scan/WifiScanner.java           WifiManager, permissions, receiver, throttling
  scan/ScanRepository.java        holds results across the activity transition
  ui/NetworkAdapter.java          binds results into your card design

app/src/main/res/layout/item_network_card.xml        one network card
app/src/main/res/drawable/badge_warning_background.xml   amber badge (new tier)
```

### Replaced files

| File | What changed |
|---|---|
| `MainActivity.java` | Real scan instead of the 3-second fake delay. Icon animation kept. |
| `DashboardActivity.java` | Full dashboard logic. |
| `activity_dashboard.xml` | IDs on stats and tabs; RecyclerView replaces the two hardcoded cards. **Design untouched.** |
| `AndroidManifest.xml` | Scanning permissions added. |
| `strings.xml` | All 15 of your strings kept, ~17 added. |

### Two-line build change

`gradle/libs.versions.toml` — add under `[versions]` and `[libraries]`:
```toml
recyclerview = "1.4.0"
recyclerview = { group = "androidx.recyclerview", name = "recyclerview", version.ref = "recyclerview" }
```
`app/build.gradle` — add to `dependencies`:
```groovy
implementation libs.recyclerview
```
Nothing else in your build config changes (still AGP 9.2.1, compileSdk 36, minSdk 24).

## How detection works

Everything is **passive**. The app reads only the beacon information every access point already broadcasts to everyone in range. It never connects to, probes, deauthenticates, or transmits anything toward any network.

### An evil twin, in one sentence

An attacker stands up an AP advertising the same SSID as a network you trust. They can copy the *name* for free — but they usually can't copy the *passphrase*, so the clone runs open. That mismatch is the strongest signal available from a passive scan.

### The checks

| Check | Verdict | Why |
|---|---|---|
| Same SSID as a sibling, but **unencrypted** (Open/WEP) while the sibling has real encryption | **ROGUE** | The evil-twin signature — copied name, no copied key |
| Software-generated MAC **+** unencrypted **+** name already in use nearby | **ROGUE** | Three independent red flags on one device |
| Two or more APs sharing one SSID | SUSPICIOUS | Normal for mesh/campus/office — but also what a clone looks like |
| Same SSID, weaker-but-still-real encryption (WPA3 vs WPA2) | SUSPICIOUS | Usually just a dual-band router, deliberately *not* rogue |
| Same SSID across different hardware vendors | SUSPICIOUS | Happens legitimately, but one may not belong |
| Open network | SUSPICIOUS | Traffic readable by anyone in range |
| WEP | SUSPICIOUS | Broken; crackable in minutes |
| Locally-administered (software) MAC | SUSPICIOUS | Phone hotspots, laptops, and most improvised rogue APs |

The verdict is the most severe check that fired; every reason is shown in the "Why flagged?" dialog.

### Limitations — worth stating in your report

These are heuristics, not proof:

- **Duplicate SSIDs are usually innocent.** Every campus, hotel and home mesh runs many APs under one name. That's why a plain duplicate is only ever SUSPICIOUS, never ROGUE.
- **A patient attacker defeats most of this** by matching the encryption type and spoofing a vendor-looking MAC.
- **Nothing here detects passive eavesdropping** — only APs that are broadcasting.
- **The vendor table is ~70 entries, not the real IEEE registry.** "Unknown" means "not in the table", nothing more, and the detector never treats it as evidence. To fix properly, bundle the IEEE OUI CSV in `assets/` and load it in `OuiLookup`.

Treat a flag as "look into this", and SAFE as "nothing obvious" — not as a security guarantee.

## Running it

1. Copy the files in, merge the two build lines, Gradle sync.
2. Run on a **physical device**. Emulators have no Wi-Fi radio and return nothing.
3. Grant the permission prompt when it appears.
4. Make sure system **Location is switched on** — on Android 12 and below the platform withholds scan results entirely without it, even when your app has permission. This is the single most common reason a working scanner appears to find nothing.

### Things that are expected, not bugs

- **"Scan was throttled"** — Android limits foreground apps to roughly 4 `startScan()` calls per 2 minutes. The app falls back to the last cached results instead of showing an empty screen.
- **Your own phone's hotspot flagged SUSPICIOUS** — correct behaviour; it has a software-generated MAC.
- **Your home router appearing twice** — the 2.4 GHz and 5 GHz radios are separate BSSIDs under one SSID.

## Where to extend it

`RogueDetector.java` is where all the decision-making lives; each check is a small self-contained method. Ideas:

- **Suppress dual-band false positives** by treating BSSIDs from the same vendor that differ only in the last octet as one physical device.
- **Track APs across scans** — an SSID whose BSSID suddenly changes, or a new AP appearing with a very strong signal, is more suspicious than either fact alone. This needs persistence (Room), which is the natural next step.
- **Baseline of trusted BSSIDs** — let the user mark their own router once, then flag anything new claiming that SSID. This turns a heuristic into a much stronger signal and is probably the single highest-value addition.
- **Real OUI database** (see above).
- **Signal-strength triangulation** — walking around while watching dBm helps physically locate a rogue AP.
